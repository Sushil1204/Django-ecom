from django.contrib import admin
from django.contrib.auth.models import Group
from .models import Product, Contact

class ProductA(admin.ModelAdmin):
    list_display = ('product_name', 'product_desc', 'category', 'is_recommended', 'product_price', 'product_image', 'publish_date')

admin.site.site_header = "Eshoppers admin panel"
admin.site.site_title = "Eshoppers"
admin.site.index_title = "Eshoppers admin panel"

admin.site.register(Product, ProductA)
admin.site.register(Contact)
