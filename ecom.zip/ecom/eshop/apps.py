from django.apps import AppConfig


class EshopConfig(AppConfig):
    name = 'eshop'
