from django.shortcuts import render, HttpResponse
from .models import Product, Contact
from math import ceil

def index(request):
    products = Product.objects.all()
    params = {'range': range(1,len(products)), 'product': products} 
    return render(request, 'index.html', params)

def aboutus(request):
    return HttpResponse("about us")

def contact(request):
    if request.method=="POST":
        print(request)
        name = request.POST.get('name')
        email = request.POST.get('email')
        subject = request.POST.get('subject')
        message = request.POST.get('message')
        contact = Contact(name=name, email=email, subject=subject, main_msg=message)
        contact.save()
    return render(request, 'contact-us.html')

def tracker(request):
    return HttpResponse("tracker")

def search(request):
    return HttpResponse("search")

def product(request, proId):
    # featching product using is...
    product = Product.objects.filter(id = proId)
    #print(product)
    return render(request, 'product-details.html', {'product' : product[0]})

def checkout(request):
    return render(request, 'checkout.html')

def cart(request):
    return render(request, 'cart.html')

def login(request):
    return render(request, 'login.html')

def shop(request):
    return render(request, 'shop.html')

def error(request):
    return render(request, '404.html')