from django.urls import path
from . import views
urlpatterns = [
    path("", views.index, name="shopHome"),
    path("about/", views.aboutus, name="AboutUs"),
    path("contact/", views.contact, name="ContactUs"),
    path("tracker/", views.tracker, name="TrackingStatus"),
    path("search/", views.search, name="search"),
    path("productview/<int:proId>", views.product, name="product"),
    path("checkout/", views.checkout, name="checkout"),
    path("cart/", views.cart, name="cart"),
    path("login/", views.login, name="login"),
    path("shop/", views.shop, name="shop"),
    path("error/", views.error, name="error")
]