from django.db import models


class Product(models.Model):
    cats = (
        ('TOOLBOX', 'TOOLBOX'),
        ('HAND TOOL', 'HAND TOOL'),
        ('CUTTER WOOD', 'CUTTER WOOD'),
        ('POWER TOOLS', 'POWER TOOLS'),
        ('SAW MAP', 'SAW MAP'),
        ('ELECTRIC TOOLS', 'ELECTRIC TOOLS'),
        ('COLLAPSIBLE', 'COLLAPSIBLE'),
        ('CORDED PLANER', 'CORDED PLANER'),
    )

    recommend = (
        ('n', 'No'),
        ('y', 'Yes'),
    )
    
    product_id = models.AutoField
    product_name = models.CharField(max_length=50)
    product_desc = models.CharField(max_length=300)
    category = models.CharField(max_length=50, choices=cats, default="")
    is_recommended= models.CharField(max_length=1, choices=recommend, default="n")
    product_price = models.IntegerField(default=0)
    product_image = models.ImageField(upload_to="images", default="")
    publish_date = models.DateField()

    def __str__(self):
        return self.product_name


class Contact(models.Model):
    msg_id = models.AutoField
    name = models.CharField(max_length=50)
    email = models.CharField(max_length=40)
    subject = models.CharField(max_length=100)
    main_msg= models.CharField(max_length=300)

    def __str__(self):
        return self.name