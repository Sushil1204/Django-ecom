import django_filters


class CategoryFilter(django_filters.FilterSet):

    class meta:
        